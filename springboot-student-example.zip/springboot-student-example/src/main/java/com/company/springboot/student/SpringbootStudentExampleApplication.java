package com.company.springboot.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootStudentExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootStudentExampleApplication.class, args);
	}
	

}
