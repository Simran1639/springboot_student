package com.company.springboot.studentDto;

import javax.persistence.NamedStoredProcedureQuery;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@NamedStoredProcedureQuery(name = "firstProcedure", procedureName = "getStudentDetails")
public class StudentDto {
	
	private int studentid;
	private String studentname;
	private int studentage;
	
}