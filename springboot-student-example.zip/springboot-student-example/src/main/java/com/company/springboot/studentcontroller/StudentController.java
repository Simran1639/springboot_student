package com.company.springboot.studentcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.company.springboot.student.Dao.StudentDao;
import com.company.springboot.studentDto.StudentDto;

@RestController
public class StudentController {
	
	@Autowired
	private StudentDao studentDao;
	
	@GetMapping("/studentDetail")
	public List<StudentDto> findStudents(){
		return studentDao.getStudentInfo();
	}

}
