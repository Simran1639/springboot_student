package com.company.springboot.student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootStudentExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
